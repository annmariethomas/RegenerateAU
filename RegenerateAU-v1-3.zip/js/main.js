const URL = window.location.href.slice(7);

function facebookButtonClick() {
    var fbShare = "https://www.facebook.com/sharer/sharer.php?u="
    window.open(fbShare + URL, "_blank");
}

function twitterButtonClick() {
    var twShare = "https://twitter.com/intent/tweet?url"
    window.open(twShare + URL, "_blank");
}

function linkedinButtonClick() {
    var liShare = "https://www.linkedin.com/shareArticle?url"
    window.open(liShare + URL, "_blank");
}

function pinterestButtonClick() {
    var piShare = "https://www.pinterest.com/pin/create/button?url"
    window.open(piShare + URL, "_blank");
}